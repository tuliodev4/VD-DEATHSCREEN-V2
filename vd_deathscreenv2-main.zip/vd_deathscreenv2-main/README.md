# DeathScreen V2

![image](https://github.com/user-attachments/assets/1edd5e70-9b4d-4096-8792-a49b3e19b575)
